<?php
header('Content-Type: application/json');

// Можно добавить авторизацию для безопасности

$page = $_GET['page'] ?? 'home';
$contentFile = __DIR__ . "/../content/$page.json";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Только POST']);
    exit;
}

$data = $_POST['sections'] ?? null;
if (!is_array($data)) {
    echo json_encode(['success' => false, 'error' => 'Неверные данные']);
    exit;
}

// Формируем структуру для сохранения
$sections = [];
foreach ($data as $section) {
    $type = $section['type'] ?? '';
    $sectionData = $section['data'] ?? [];
    if (!$type) continue;

    // Безопасность: можно фильтровать поля, здесь просто оставим все
    $sections[] = [
        'type' => $type,
        'data' => $sectionData
    ];
}

$content = [
    'title' => ucfirst($page),
    'sections' => $sections
];

// Сохраняем JSON с форматированием
if (file_put_contents($contentFile, json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Не удалось сохранить файл']);
}