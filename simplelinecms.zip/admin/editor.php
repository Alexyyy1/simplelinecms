<?php
// Простая защита: можно добавить авторизацию здесь
// Для упрощения — пока нет

$page = $_GET['page'] ?? 'home';
$contentFile = __DIR__ . "/../content/$page.json";

// Если файл не существует — создаём базовый
if (!file_exists($contentFile)) {
    $defaultContent = [
        'title' => ucfirst($page),
        'sections' => []
    ];
    file_put_contents($contentFile, json_encode($defaultContent, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$content = json_decode(file_get_contents($contentFile), true);
$sections = $content['sections'] ?? [];
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Редактор SimpleLineCMS — <?php echo htmlspecialchars($page); ?></title>
    <style>
        body { font-family: Arial, sans-serif; background: #222; color: #eee; margin: 0; padding: 20px; }
        h1 { margin-bottom: 1em; }
        .section { background: #333; padding: 15px; margin-bottom: 15px; border-radius: 8px; }
        label { display: block; margin-top: 10px; }
        input[type=text], textarea, select { width: 100%; padding: 8px; margin-top: 5px; border-radius: 4px; border: none; }
        button { margin-top: 10px; padding: 10px 20px; background: #0a74da; border: none; color: white; cursor: pointer; border-radius: 4px; }
        button:hover { background: #095bb5; }
        .add-section { background: #444; padding: 15px; margin-bottom: 20px; border-radius: 8px; }
    </style>
</head>
<body>

<h1>Редактор SimpleLineCMS — страница "<?php echo htmlspecialchars($page); ?>"</h1>

<div class="add-section">
    <h2>Добавить новую секцию</h2>
    <form id="addSectionForm">
        <label for="sectionType">Тип секции:</label>
        <select id="sectionType" name="type" required>
            <option value="">-- Выберите тип --</option>
            <option value="hero">Hero (главный баннер)</option>
            <option value="text">Текст</option>
            <option value="image">Изображение</option>
        </select>
        <button type="submit">Добавить секцию</button>
    </form>
</div>

<form id="sectionsForm">
    <?php foreach ($sections as $index => $section): ?>
        <div class="section" data-index="<?php echo $index; ?>">
            <h3>Секция #<?php echo $index + 1; ?> — <?php echo htmlspecialchars($section['type']); ?></h3>
            <button type="button" class="deleteSection" style="float:right;background:#b33;">Удалить</button>
            <?php
                $type = $section['type'];
                $data = $section['data'];
                if ($type === 'hero'):
            ?>
                <label>Заголовок (headline):<input type="text" name="sections[<?php echo $index; ?>][data][headline]" value="<?php echo htmlspecialchars($data['headline'] ?? ''); ?>"></label>
                <label>Подзаголовок (subheadline):<input type="text" name="sections[<?php echo $index; ?>][data][subheadline]" value="<?php echo htmlspecialchars($data['subheadline'] ?? ''); ?>"></label>
                <label>Текст кнопки:<input type="text" name="sections[<?php echo $index; ?>][data][button_text]" value="<?php echo htmlspecialchars($data['button_text'] ?? ''); ?>"></label>
                <label>Ссылка кнопки:<input type="text" name="sections[<?php echo $index; ?>][data][button_link]" value="<?php echo htmlspecialchars($data['button_link'] ?? ''); ?>"></label>
            <?php elseif ($type === 'text'): ?>
                <label>Заголовок:<input type="text" name="sections[<?php echo $index; ?>][data][title]" value="<?php echo htmlspecialchars($data['title'] ?? ''); ?>"></label>
                <label>Текст:<textarea name="sections[<?php echo $index; ?>][data][content]" rows="4"><?php echo htmlspecialchars($data['content'] ?? ''); ?></textarea></label>
            <?php elseif ($type === 'image'): ?>
                <label>Путь к изображению:<input type="text" name="sections[<?php echo $index; ?>][data][src]" value="<?php echo htmlspecialchars($data['src'] ?? ''); ?>"></label>
                <label>Alt текст:<input type="text" name="sections[<?php echo $index; ?>][data][alt]" value="<?php echo htmlspecialchars($data['alt'] ?? ''); ?>"></label>
                <label>Подпись:<input type="text" name="sections[<?php echo $index; ?>][data][caption]" value="<?php echo htmlspecialchars($data['caption'] ?? ''); ?>"></label>
            <?php endif; ?>
            <input type="hidden" name="sections[<?php echo $index; ?>][type]" value="<?php echo htmlspecialchars($type); ?>">
        </div>
    <?php endforeach; ?>

    <button type="submit" style="margin-top: 20px;">Сохранить изменения</button>
</form>

<script>
document.getElementById('addSectionForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const type = document.getElementById('sectionType').value;
    if (!type) return alert('Выберите тип секции');

    // Добавляем новую секцию в форму
    const form = document.getElementById('sectionsForm');
    const index = form.querySelectorAll('.section').length;

    const div = document.createElement('div');
    div.className = 'section';
    div.dataset.index = index;

    let html = `<h3>Секция #${index + 1} — ${type}</h3>`;
    html += `<button type="button" class="deleteSection" style="float:right;background:#b33;">Удалить</button>`;

    if (type === 'hero') {
        html += `
            <label>Заголовок (headline):<input type="text" name="sections[${index}][data][headline]" value=""></label>
            <label>Подзаголовок (subheadline):<input type="text" name="sections[${index}][data][subheadline]" value=""></label>
            <label>Текст кнопки:<input type="text" name="sections[${index}][data][button_text]" value=""></label>
            <label>Ссылка кнопки:<input type="text" name="sections[${index}][data][button_link]" value=""></label>
        `;
    } else if (type === 'text') {
        html += `
            <label>Заголовок:<input type="text" name="sections[${index}][data][title]" value=""></label>
            <label>Текст:<textarea name="sections[${index}][data][content]" rows="4"></textarea></label>
        `;
    } else if (type === 'image') {
        html += `
            <label>Путь к изображению:<input type="text" name="sections[${index}][data][src]" value=""></label>
            <label>Alt текст:<input type="text" name="sections[${index}][data][alt]" value=""></label>
            <label>Подпись:<input type="text" name="sections[${index}][data][caption]" value=""></label>
        `;
    }
    html += `<input type="hidden" name="sections[${index}][type]" value="${type}">`;

    div.innerHTML = html;
    form.insertBefore(div, form.querySelector('button[type="submit"]'));

    // Добавить обработчик удаления
    div.querySelector('.deleteSection').addEventListener('click', function() {
        div.remove();
        updateSectionNumbers();
    });
});

function updateSectionNumbers() {
    const sections = document.querySelectorAll('.section');
    sections.forEach((sec, i) => {
        sec.dataset.index = i;
        sec.querySelector('h3').textContent = `Секция #${i + 1} — ${sec.querySelector('input[type=hidden]').value}`;
        // Обновить имена input, чтобы индекс был правильным
        sec.querySelectorAll('input, textarea').forEach(input => {
            const name = input.name;
            const newName = name.replace(/sections\d+/, `sections[${i}]`);
            input.name = newName;
        });
    });
}

// Добавляем обработчики удаления для существующих секций
document.querySelectorAll('.deleteSection').forEach(btn => {
    btn.addEventListener('click', function() {
        btn.closest('.section').remove();
        updateSectionNumbers();
    });
});

document.getElementById('sectionsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const data = new FormData(this);

    fetch('save.php?page=<?php echo urlencode($page); ?>', {
        method: 'POST',
        body: data
    })
    .then(res => res.json())
    .then(json => {
        if (json.success) {
            alert('Изменения сохранены');
            location.reload();
        } else {
            alert('Ошибка: ' + (json.error || 'Неизвестная ошибка'));
        }
    })
    .catch(() => alert('Ошибка при сохранении'));
});
</script>

</body>
</html>