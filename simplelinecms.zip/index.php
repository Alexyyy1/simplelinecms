<?php
// Загрузка страницы (по умолчанию — home)
$page = $_GET['page'] ?? 'home';
$contentFile = __DIR__ . "/content/$page.json";

if (!file_exists($contentFile)) {
    die("Страница не найдена");
}

// Загружаем JSON-контент
$content = json_decode(file_get_contents($contentFile), true);
$sections = $content['sections'] ?? [];

include 'themes/default/header.php';

// Подключаем секции
foreach ($sections as $section) {
    $type = $section['type'] ?? '';
    $data = $section['data'] ?? [];

    $sectionFile = "themes/default/sections/{$type}.php";
    if (file_exists($sectionFile)) {
        include $sectionFile;
    } else {
        echo "<p style='color:red;'>Шаблон секции '$type' не найден.</p>";
    }
}

include 'themes/default/footer.php';
?>