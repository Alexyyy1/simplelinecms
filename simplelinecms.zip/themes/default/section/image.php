<?php
$src = htmlspecialchars($data['src'] ?? '');
$alt = htmlspecialchars($data['alt'] ?? '');
$caption = htmlspecialchars($data['caption'] ?? '');
?>

<section class="image-section" style="text-align: center; padding: 40px 20px;">
    <?php if ($src): ?>
        <img src="<?php echo $src; ?>" alt="<?php echo $alt; ?>" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
    <?php endif; ?>
    <?php if ($caption): ?>
        <p style="margin-top: 10px; font-style: italic; color: #666;"><?php echo $caption; ?></p>
    <?php endif; ?>
</section>