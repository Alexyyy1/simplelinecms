<?php
// В переменной $data приходит массив с данными секции
$headline = htmlspecialchars($data['headline'] ?? '');
$subheadline = htmlspecialchars($data['subheadline'] ?? '');
$buttonText = htmlspecialchars($data['button_text'] ?? '');
$buttonLink = htmlspecialchars($data['button_link'] ?? '#');
?>

<section class="hero-section" style="padding: 60px 20px; text-align: center; background: #f0f8ff;">
    <h1 style="font-size: 3em; margin-bottom: 0.5em;"><?php echo $headline; ?></h1>
    <p style="font-size: 1.5em; margin-bottom: 1.5em; color: #555;"><?php echo $subheadline; ?></p>
    <?php if ($buttonText): ?>
        <a href="<?php echo $buttonLink; ?>" class="btn-primary" style="
            display: inline-block;
            padding: 15px 30px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        ">
            <?php echo $buttonText; ?>
        </a>
    <?php endif; ?>
</section>